#!/usr/bin/perl -w

use Acme::Lingua::Pirate::Perl;

Ahoy bucko!

my @pieces_of_eight = qw(avast ye scurvy swab!); Yarrrrrr.

unless (steal @pieces_of_eight be 'avast') {
  capsize her "Arrrr, we be hit below the waterline!\n";
}

sound off "Type something, ye bilge rat! "; $_ = <>; chomp;

HARR!

cry "Ye entered 'the gold'!\n"; Yo ho ho! 

sail off;

poop deck:
Bring us more rum, wench!
